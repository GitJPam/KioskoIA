"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Settings, User, Store, Bell, Shield, Loader2 } from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useAuthStore } from "@/store";
import { toast } from "sonner";

export default function ConfiguracionPage() {
  const router = useRouter();
  const { user, isAuthenticated, setLoading, setUser } = useAuthStore();

  const [loading, setLoading2] = useState(true);
  const [saving, setSaving] = useState(false);

  // Check auth
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch("/api/auth/me");
        const result = await response.json();
        if (!result.success || !result.data?.user) {
          router.push("/login");
          return;
        }
        setUser(result.data.user);
      } catch {
        router.push("/login");
      } finally {
        setLoading(false);
        setLoading2(false);
      }
    };
    checkAuth();
  }, [router, setLoading, setUser]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
      </div>
    );
  }

  return (
    <AppShell title="Configuración">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Settings className="w-7 h-7 text-emerald-500" />
            Configuración
          </h2>
          <p className="text-gray-500">
            Gestiona la configuración de tu tienda
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* User Profile */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <User className="w-5 h-5" />
                Perfil de Usuario
              </CardTitle>
              <CardDescription>
                Información de tu cuenta
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center">
                  <span className="text-xl font-bold text-emerald-700">
                    {user?.name?.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{user?.name}</p>
                  <p className="text-sm text-gray-500">{user?.email}</p>
                  <Badge className="mt-1">
                    {user?.role === "ADMIN" ? "Administrador" : "Tendero"}
                  </Badge>
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="space-y-2">
                  <Label>Nombre</Label>
                  <Input value={user?.name || ""} disabled />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input value={user?.email || ""} disabled />
                </div>
                <div className="space-y-2">
                  <Label>Teléfono</Label>
                  <Input value={user?.phone || ""} disabled placeholder="No configurado" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Store Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Store className="w-5 h-5" />
                Información de la Tienda
              </CardTitle>
              <CardDescription>
                Datos de tu negocio
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Nombre de la tienda</Label>
                <Input defaultValue="Kiosko Escolar" />
              </div>
              <div className="space-y-2">
                <Label>Dirección</Label>
                <Input defaultValue="Colegio San José, Palmira" />
              </div>
              <div className="space-y-2">
                <Label>Teléfono de contacto</Label>
                <Input placeholder="+57 300 123 4567" />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Clasificar alimentos saludables</p>
                  <p className="text-sm text-gray-500">
                    Mostrar indicador de productos saludables
                  </p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Alertas de stock bajo</p>
                  <p className="text-sm text-gray-500">
                    Recibir notificaciones cuando el stock sea bajo
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>

          {/* Notifications */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Notificaciones
              </CardTitle>
              <CardDescription>
                Configura tus preferencias de notificación
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Resumen diario</p>
                  <p className="text-sm text-gray-500">
                    Recibir resumen de ventas al final del día
                  </p>
                </div>
                <Switch />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Alertas de inventario</p>
                  <p className="text-sm text-gray-500">
                    Notificar cuando productos estén por agotarse
                  </p>
                </div>
                <Switch defaultChecked />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Predicciones de IA</p>
                  <p className="text-sm text-gray-500">
                    Sugerencias automáticas de pedidos
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>

          {/* System Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Información del Sistema
              </CardTitle>
              <CardDescription>
                Estado y versión del sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2">
                <span className="text-gray-500">Versión</span>
                <Badge variant="outline">1.0.0</Badge>
              </div>
              <Separator />
              <div className="flex items-center justify-between py-2">
                <span className="text-gray-500">Base de datos</span>
                <Badge className="bg-emerald-100 text-emerald-700">SQLite</Badge>
              </div>
              <Separator />
              <div className="flex items-center justify-between py-2">
                <span className="text-gray-500">Estado</span>
                <Badge className="bg-emerald-100 text-emerald-700">Activo</Badge>
              </div>
              <Separator />
              <div className="flex items-center justify-between py-2">
                <span className="text-gray-500">Última sincronización</span>
                <span className="text-sm">
                  {new Date().toLocaleTimeString("es-CO", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
